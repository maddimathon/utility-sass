---
title: About
category: Docs
children: 
  - ./CHANGELOG.md
  - ./LICENSE.md
---

<!--README_HEADER-->
# Utility Sass @ 0.3.2
<!--/README_HEADER-->

<!--README_DESC-->
Sass (scss) utilities to use in a variety of projects with an opinionated,
optionally configurable design token system.
<!--/README_DESC-->


## Changelog

<!--README_DOCS_CHANGELOG-->
Read it from [the source](https://github.com/maddimathon/utility-sass/blob/main/CHANGELOG.md) 
or 
[the docs site](https://maddimathon.github.io/utility-sass/Changelog.html).
<!--/README_DOCS_CHANGELOG-->


## Install

<!--README_INSTALL-->
```sh
# for full releases only, add
# `@maddimathon/utility-sass:registry=https://registry.npmjs.org` to your `.npmrc` file
npm i -D @maddimathon/utility-sass@^0.3.2

# for pre-releases
npm i -D github:maddimathon/utility-sass#semver:^0.3.2
```
<!--/README_INSTALL-->


## Use

For a better overview of all exported items, including types, see the
documentation below.

```scss
@forward 'pkg:@maddimathon/utility-sass/config' with (
    // ...
);
@forward 'pkg:@maddimathon/utility-sass/tokens' with (
    // ...
);

@use 'pkg:@maddimathon/utility-sass';

@use 'pkg:@maddimathon/utility-sass/colour';
@use 'pkg:@maddimathon/utility-sass/demo';
@use 'pkg:@maddimathon/utility-sass/feature-check';
@use 'pkg:@maddimathon/utility-sass/list';
@use 'pkg:@maddimathon/utility-sass/map';
@use 'pkg:@maddimathon/utility-sass/math';
@use 'pkg:@maddimathon/utility-sass/meta';
@use 'pkg:@maddimathon/utility-sass/selector';
@use 'pkg:@maddimathon/utility-sass/string';
```

<!--README_DOCS_CTA-->
<a href="https://maddimathon.github.io/utility-sass" class="button">Read Documentation</a>
<!--/README_DOCS_CTA-->


## Development & Coding Practices

This library is maintained by [Maddi Mathon](https://www.maddimathon.com/web) and is
currently unlikely to accept other contributions.

Each file that defines items/exports should limit its exports to one item and
its associated types, if applicable.  Occasionally (and judiciously), it may
make more sense to define a small number of closely-related items in the same
file.

### Directory Structure

All files required for development but ommitted from the published package
should be in `src/`.

Files compiled in order to be included in the published package should be
written to `dist/`.

Documentation should be a valid HTML static site (for use with GitHub Pages)
with a home page at `docs/index.html`.

Scripts used for development (building, publishing, testing, etc.) should be in
`.scripts/`.  Subfolders for classes, functions, and variables separate
resources from scripts meant to be run via npm.

### Naming Conventions

Long and clear is better than short and confusing.

Abstract classes should start with `Abstract` (e.g., `AbstractClass`).

Classes made only to be children of other classes should be prefixed with their
parent class (e.g., `ParentClass_[Child]`).

### Documentation

Documentation is good and helpful.  The docs website for this package is mostly
auto-generated from block comments and typing in the source.  Keeping the readme
and changelog up to date is also important.

#### TypeDoc

Documentation for the included JavaScript is generated from the TypeScript types
and block comments in the source.  Every new addition should be thoroughly
documented from the start.

To include source code in documentation, add the `@source` block tag (uses
[typedoc-plugin-inline-sources](https://www.npmjs.com/package/typedoc-plugin-inline-sources)).

### Unit Testing

Unit tests are written in the source but run after compile and minimize (via
`Build` or `Test` scripts).  Tests should be written in a file with the same path
but with `.test` added before the extension — e.g., `myFunction.ts` is tested by
`myFunction.test.ts`.

### TypeScript

Every subdirectory should have its own `index.ts` that re-exports the contents
of its files.  **Types should also be tested** using the utility types in 
[@maddimathon/utility-typescript](https://github.com/maddimathon/utility-typescript)’s
`Types.Test`.



## License

This library uses the [MIT license](LICENSE.md).  Please read and understand
the license — I promise it’s short!